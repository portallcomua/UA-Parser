<?php
/**
 * Plugin Name: Woo Smart Parser 3
 * Description: Універсальний парсер товарів у WooCommerce: CSV, імпорт у чернетки, оновлення існуючих товарів, шаблони сайтів.
 * Version: 3.0.1
 * Author: Portall + GPT
 * Text Domain: woo-smart-parser
 */
if (!defined('ABSPATH')) exit;

final class WSP3 {
    const VER='3.0.1';
    const OPT_PROFILES='wsp3_profiles';
    const OPT_JOBS='wsp3_jobs';
    const META_SRC_URL='_wsp_source_url';
    const META_SRC_HASH='_wsp_source_image_hash';
    const NONCE='wsp3_nonce';

    public function __construct(){
        add_action('admin_menu',[$this,'menu']);
        add_action('admin_enqueue_scripts',[$this,'assets']);
        foreach(['profiles','save_profile','delete_profile','auto_detect','test_product','collect_links','start_job','run_job','csv_download','proxy_picker'] as $a){
            add_action('wp_ajax_wsp3_'.$a,[$this,'ajax_'.$a]);
        }
    }
    public function menu(){ add_menu_page('Woo Smart Parser','Smart Parser','manage_woocommerce','wsp3',[$this,'page'],'dashicons-download',56); }
    public function assets($hook){
        if($hook!=='toplevel_page_wsp3') return;
        wp_enqueue_style('wsp3',plugin_dir_url(__FILE__).'assets/admin.css',[],self::VER);
        wp_enqueue_script('wsp3',plugin_dir_url(__FILE__).'assets/admin.js',['jquery'],self::VER,true);
        wp_localize_script('wsp3','WSP3',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce(self::NONCE)]);
    }
    private function check(){ if(!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) wp_send_json_error('Немає прав'); check_ajax_referer(self::NONCE,'nonce'); }
    public function page(){ ?>
    <div class="wrap wsp3-wrap">
      <h1>Woo Smart Parser 3</h1>
      <p class="wsp3-muted">Універсальний збір товарів з категорії або всього сайту → CSV WooCommerce / чернетки / CSV + чернетки.</p>
      <div class="wsp3-grid">
        <section class="wsp3-card"><h2>1. Шаблон сайту</h2>
          <label>Вибрати шаблон</label><select id="wsp-profile"></select>
          <div class="wsp3-row"><button class="button" id="wsp-new">Новий</button><button class="button" id="wsp-save">Зберегти шаблон</button><button class="button" id="wsp-delete">Видалити</button></div>
          <label>Назва шаблону</label><input id="p-name" class="widefat" placeholder="Наприклад: intimo.com.ua">
          <label>URL тестового товару</label><input id="p-test" class="widefat" placeholder="https://site.ua/product/...">
          <div class="wsp3-row"><button class="button button-primary" id="wsp-auto">Автопошук полів</button><button class="button" id="wsp-test">Тест товару</button><button class="button" id="wsp-picker">Вибір кліком</button></div>
          <div id="wsp-test-result"></div>
        </section>
        <section class="wsp3-card"><h2>2. Поля товару</h2>
          <p class="wsp3-muted">Можна CSS або XPath. Приклади: <code>h1</code>, <code>.price</code>, <code>//h1</code>.</p>
          <div id="wsp-fields"></div>
        </section>
      </div>
      <section class="wsp3-card"><h2>3. Збір товарів</h2>
        <div class="wsp3-grid2">
          <div><label>Що парсимо</label><select id="crawl-mode"><option value="category">Одну категорію / розділ</option><option value="site">Весь сайт / магазин</option></select></div>
          <div><label>Стартовий URL</label><input id="start-url" class="widefat" placeholder="URL категорії або головна сайту"></div>
          <div><label>Макс. сторінок для обходу</label><input id="max-pages" type="number" value="25" min="1" max="300"></div>
          <div><label>Макс. товарів</label><input id="max-products" type="number" value="100" min="1" max="5000"></div>
        </div>
        <label>Селектор посилань на товари</label><input id="link-selector" class="widefat" placeholder="a[href*='product'], .product a" value="a[href*='product'], a[href*='tovar'], a[href*='shop']">
        <label>Селектор наступної сторінки / пагінації</label><input id="next-selector" class="widefat" placeholder="a.next, .pagination a.next, a[rel=next]" value="a.next, a[rel='next'], .pagination a.next">
        <div class="wsp3-row"><button class="button" id="wsp-collect">Зібрати посилання</button><span id="collect-info"></span></div>
        <textarea id="product-urls" rows="7" class="widefat" placeholder="Тут будуть URL товарів. Можна вставити вручну по одному в рядок."></textarea>
      </section>
      <section class="wsp3-card"><h2>4. Режим імпорту</h2>
        <label><input type="checkbox" id="make-csv" checked> Сформувати CSV WooCommerce</label><br>
        <label><input type="checkbox" id="import-products"> Імпорт у WooCommerce</label><br>
        <label><input type="checkbox" id="as-draft" checked> Створювати нові товари як чернетки</label><br>
        <label><input type="checkbox" id="update-existing" checked> Не дублювати: оновлювати існуючі товари</label><br>
        <label><input type="checkbox" id="upload-images" checked> Завантажувати фото в медіатеку</label><br>
        <label><input type="checkbox" id="refresh-images"> При повторному імпорті оновлювати фото</label>
        <div class="wsp3-row"><button class="button button-primary button-hero" id="wsp-start">Запустити</button></div>
        <div id="job-progress"></div>
      </section>
    </div>
    <?php }

    private function fields(){return ['name'=>'Назва','regular_price'=>'Ціна','sale_price'=>'Акційна ціна','sku'=>'SKU / Артикул','short_description'=>'Короткий опис','description'=>'Опис','main_image'=>'Головне фото','gallery'=>'Галерея','brand'=>'Бренд','attributes'=>'Характеристики'];}
    public function ajax_profiles(){ $this->check(); wp_send_json_success(['profiles'=>$this->get_profiles(),'fields'=>$this->fields()]); }
    private function get_profiles(){ $p=get_option(self::OPT_PROFILES,[]); return is_array($p)?$p:[]; }
    public function ajax_save_profile(){ $this->check(); $profile=$this->clean_profile($_POST['profile']??[]); if(empty($profile['id'])) $profile['id']='p'.time().wp_rand(100,999); $profiles=$this->get_profiles(); $profiles[$profile['id']]=$profile; update_option(self::OPT_PROFILES,$profiles,false); wp_send_json_success($profile); }
    public function ajax_delete_profile(){ $this->check(); $id=sanitize_key($_POST['id']??''); $p=$this->get_profiles(); unset($p[$id]); update_option(self::OPT_PROFILES,$p,false); wp_send_json_success(); }
    private function clean_profile($p){
        $out=['id'=>sanitize_key($p['id']??''),'name'=>sanitize_text_field($p['name']??''),'test_url'=>esc_url_raw($p['test_url']??''),'link_selector'=>sanitize_text_field($p['link_selector']??''),'next_selector'=>sanitize_text_field($p['next_selector']??''),'selectors'=>[]];
        foreach($this->fields() as $k=>$v){ $out['selectors'][$k]=sanitize_text_field($p['selectors'][$k]??''); }
        return $out;
    }
    private function safe_url($url){
        $url=esc_url_raw(trim($url)); if(!$url || !preg_match('~^https?://~i',$url)) return false;
        $host=parse_url($url,PHP_URL_HOST); if(!$host) return false;
        if(preg_match('~^(localhost|127\.|10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.)~',$host)) return false;
        return $url;
    }
    private function fetch($url){
        $url=$this->safe_url($url); if(!$url) return new WP_Error('bad_url','Невірний або небезпечний URL');
        $r=wp_remote_get($url,['timeout'=>20,'redirection'=>5,'user-agent'=>'Mozilla/5.0 WooSmartParser/3.0 (+WordPress)']);
        if(is_wp_error($r)) return $r; $code=wp_remote_retrieve_response_code($r); if($code<200||$code>=400) return new WP_Error('http','HTTP '.$code);
        $body=wp_remote_retrieve_body($r); if(!$body) return new WP_Error('empty','Порожня сторінка'); return $body;
    }
    private function dom($html){ libxml_use_internal_errors(true); $d=new DOMDocument(); $d->loadHTML('<?xml encoding="UTF-8">'.$html); return new DOMXPath($d); }
    private function css_to_xpath($css){
        $css=trim($css); if($css==='') return '';
        if(str_starts_with($css,'//')||str_starts_with($css,'(')) return $css;
        $parts=array_map('trim',explode(',',$css)); $x=[];
        foreach($parts as $s){
            $tag='*'; $cond=[];
            if(preg_match('/^[a-z0-9_-]+/i',$s,$m)) $tag=$m[0];
            if(preg_match_all('/\.([a-zA-Z0-9_-]+)/',$s,$m)) foreach($m[1] as $c) $cond[]="contains(concat(' ',normalize-space(@class),' '),' $c ')";
            if(preg_match('/#([a-zA-Z0-9_-]+)/',$s,$m)) $cond[]="@id='{$m[1]}'";
            if(preg_match_all('/\[([^=\]]+)(?:=["\']?([^"\'\]]+)["\']?)?\]/',$s,$m,PREG_SET_ORDER)) foreach($m as $a){ $attr=preg_replace('/[^a-zA-Z0-9_:-]/','',$a[1]); if(isset($a[2])&&$a[2]!=='') $cond[]="contains(@$attr,'".esc_attr($a[2])."')"; else $cond[]="@$attr"; }
            if(preg_match('/\s+([a-z0-9_.#\[]+)/i',$s,$m)){ /* простий fallback для вкладених */ }
            $x[]='//'.$tag.($cond?'['.implode(' and ',$cond).']':'');
        }
        return count($x)>1?'('.implode(' | ',$x).')':$x[0];
    }
    private function query($xp,$selector){ $x=$this->css_to_xpath($selector); if(!$x) return false; try{return $xp->query($x);}catch(Exception $e){return false;} }
    private function node_text($n){ return trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($n->textContent),ENT_QUOTES,'UTF-8'))); }
    private function abs_url($url,$base){ if(!$url)return''; $url=trim($url); if(str_starts_with($url,'//')) return parse_url($base,PHP_URL_SCHEME).':'.$url; if(preg_match('~^https?://~i',$url)) return $url; $p=parse_url($base); $root=$p['scheme'].'://'.$p['host']; if(str_starts_with($url,'/')) return $root.$url; $dir=preg_replace('~/[^/]*$~','/',$p['path']??'/'); return $root.$dir.$url; }
    private function img_src($n,$base){ foreach(['src','data-src','data-lazy-src','data-original','data-large_image'] as $a){$v=$n->getAttribute($a); if($v) return $this->abs_url($v,$base);} $ss=$n->getAttribute('srcset')?:$n->getAttribute('data-srcset'); if($ss){$first=trim(explode(',', $ss)[0]); return $this->abs_url(trim(explode(' ',$first)[0]),$base);} return ''; }
    private function parse_product($url,$selectors){
        $html=$this->fetch($url); if(is_wp_error($html)) return $html; $xp=$this->dom($html); $data=['source_url'=>$url];
        foreach($this->fields() as $field=>$label){ $sel=$selectors[$field]??''; if(!$sel) continue; $nodes=$this->query($xp,$sel); if(!$nodes||!$nodes->length) continue;
            if(in_array($field,['main_image','gallery'],true)){ $imgs=[]; foreach($nodes as $n){ if($n instanceof DOMElement){ $src=$this->img_src($n->tagName==='img'?$n:$n->getElementsByTagName('img')->item(0),$url); if($src)$imgs[]=$src; } } $data[$field]=array_values(array_unique($imgs)); }
            elseif($field==='attributes'){ $vals=[]; foreach($nodes as $n){$t=$this->node_text($n); if($t)$vals[]=$t;} $data[$field]=$vals; }
            else { $data[$field]=$this->node_text($nodes->item(0)); }
        }
        $data['regular_price']=$this->price($data['regular_price']??''); $data['sale_price']=$this->price($data['sale_price']??'');
        if(empty($data['name'])) $data['name']='Товар '.md5($url);
        return $data;
    }
    private function price($s){ if(!$s)return''; $s=preg_replace('/[^0-9,\.]/','',$s); $s=str_replace(',','.',$s); if(substr_count($s,'.')>1){$s=str_replace('.','',$s); } return $s; }
    public function ajax_auto_detect(){ $this->check(); $url=$this->safe_url($_POST['url']??''); if(!$url) wp_send_json_error('Невірний URL'); $html=$this->fetch($url); if(is_wp_error($html)) wp_send_json_error($html->get_error_message()); $xp=$this->dom($html); $c=[
        'name'=>['h1','[itemprop=name]','.product_title','.product-name h1','.entry-title'],
        'regular_price'=>['[itemprop=price]','.price','.woocommerce-Price-amount','.product-price','span:contains(₴)'],
        'description'=>['[itemprop=description]','.woocommerce-product-details__short-description','.product-description','.description','#description'],
        'main_image'=>['.woocommerce-product-gallery__image img','.product-image img','img.wp-post-image','[itemprop=image]','img'],
        'sku'=>['.sku','[itemprop=sku]','.product-code','.artikul'],
        'gallery'=>['.woocommerce-product-gallery img','.product-gallery img','.gallery img'],
        'attributes'=>['.woocommerce-product-attributes tr','.characteristics tr','.attributes tr','.params tr']
      ]; $out=[]; foreach($c as $f=>$sels){ foreach($sels as $sel){ if(str_contains($sel,':contains')) continue; $nodes=$this->query($xp,$sel); if($nodes&&$nodes->length){ $ex=in_array($f,['main_image','gallery'],true)?$this->img_src($nodes->item(0),$url):$this->node_text($nodes->item(0)); if($ex){$out[$f]=['selector'=>$sel,'example'=>mb_substr($ex,0,160)]; break;} } } } wp_send_json_success($out); }
    public function ajax_test_product(){ $this->check(); $url=$this->safe_url($_POST['url']??''); $selectors=$_POST['selectors']??[]; $data=$this->parse_product($url,array_map('sanitize_text_field',$selectors)); if(is_wp_error($data)) wp_send_json_error($data->get_error_message()); wp_send_json_success($data); }
    public function ajax_collect_links(){
        $this->check(); $start=$this->safe_url($_POST['url']??''); $mode=sanitize_text_field($_POST['mode']??'category'); $link_sel=sanitize_text_field($_POST['link_selector']??'a'); $next_sel=sanitize_text_field($_POST['next_selector']??''); $max_pages=min(300,max(1,intval($_POST['max_pages']??25))); $max_products=min(5000,max(1,intval($_POST['max_products']??100)));
        if(!$start) wp_send_json_error('Невірний стартовий URL'); $queue=[$start]; $seen=[]; $products=[]; $base_host=parse_url($start,PHP_URL_HOST);
        while($queue && count($seen)<$max_pages && count($products)<$max_products){ $url=array_shift($queue); if(isset($seen[$url]))continue; $seen[$url]=1; $html=$this->fetch($url); if(is_wp_error($html)) continue; $xp=$this->dom($html);
            $nodes=$this->query($xp,$link_sel); if($nodes) foreach($nodes as $n){ if(!($n instanceof DOMElement))continue; $href=$this->abs_url($n->getAttribute('href'),$url); if(!$href||parse_url($href,PHP_URL_HOST)!==$base_host)continue; $products[$href]=1; if(count($products)>=$max_products)break; }
            if($mode==='category' && $next_sel){ $ns=$this->query($xp,$next_sel); if($ns) foreach($ns as $n){$href=$this->abs_url($n->getAttribute('href'),$url); if($href&&!isset($seen[$href])&&parse_url($href,PHP_URL_HOST)===$base_host)$queue[]=$href;} }
            if($mode==='site'){ $as=$xp->query('//a[@href]'); foreach($as as $a){ $href=$this->abs_url($a->getAttribute('href'),$url); if($href&&!isset($seen[$href])&&parse_url($href,PHP_URL_HOST)===$base_host && count($seen)+count($queue)<$max_pages*2) $queue[]=$href; } }
        }
        wp_send_json_success(['urls'=>array_keys($products),'pages'=>count($seen)]);
    }
    public function ajax_start_job(){ $this->check(); $urls=array_filter(array_map('trim',explode("\n",wp_unslash($_POST['urls']??'')))); $selectors=array_map('sanitize_text_field',$_POST['selectors']??[]); if(!$urls) wp_send_json_error('Немає URL товарів'); $job='j'.time().wp_rand(1000,9999); $jobs=get_option(self::OPT_JOBS,[]); $jobs[$job]=['id'=>$job,'urls'=>array_values($urls),'done'=>0,'ok'=>0,'errors'=>0,'rows'=>[],'selectors'=>$selectors,'opts'=>$_POST['opts']??[],'log'=>[],'created'=>time()]; update_option(self::OPT_JOBS,$jobs,false); wp_send_json_success(['job'=>$job,'total'=>count($urls)]); }
    public function ajax_run_job(){ $this->check(); $job=sanitize_key($_POST['job']??''); $jobs=get_option(self::OPT_JOBS,[]); if(empty($jobs[$job])) wp_send_json_error('Завдання не знайдено'); $j=&$jobs[$job]; $batch=3; for($i=0;$i<$batch && $j['done']<count($j['urls']);$i++){ $url=$j['urls'][$j['done']]; $data=$this->parse_product($url,$j['selectors']); if(is_wp_error($data)){ $j['errors']++; $j['log'][]='❌ '.$url.' — '.$data->get_error_message(); } else { $j['rows'][]=$data; $j['ok']++; if(!empty($j['opts']['import_products'])) $this->import_product($data,$j['opts']); $j['log'][]='✅ '.($data['name']??$url); } $j['done']++; }
        update_option(self::OPT_JOBS,$jobs,false); wp_send_json_success(['done'=>$j['done'],'total'=>count($j['urls']),'ok'=>$j['ok'],'errors'=>$j['errors'],'finished'=>$j['done']>=count($j['urls']),'csv'=>admin_url('admin-ajax.php?action=wsp3_csv_download&nonce='.wp_create_nonce(self::NONCE).'&job='.$job),'log'=>array_slice($j['log'],-10)]); }
    private function find_existing($data){ if(!empty($data['sku']) && function_exists('wc_get_product_id_by_sku')){ $id=wc_get_product_id_by_sku($data['sku']); if($id)return $id; } $q=new WP_Query(['post_type'=>'product','post_status'=>'any','meta_key'=>self::META_SRC_URL,'meta_value'=>$data['source_url'],'fields'=>'ids','posts_per_page'=>1]); if($q->posts)return $q->posts[0]; if(!empty($data['name'])){ $p=get_page_by_title($data['name'],OBJECT,'product'); if($p)return $p->ID; } return 0; }
    private function import_product($data,$opts){ if(!class_exists('WC_Product_Simple')) return 0; $update=!empty($opts['update_existing']); $id=$update?$this->find_existing($data):0; $product=$id?wc_get_product($id):new WC_Product_Simple(); $product->set_name($data['name']); if(!$id)$product->set_status(!empty($opts['as_draft'])?'draft':'publish'); if(!empty($data['regular_price'])) $product->set_regular_price($data['regular_price']); if(!empty($data['sale_price'])) $product->set_sale_price($data['sale_price']); if(!empty($data['sku'])){ try{$product->set_sku($data['sku']);}catch(Exception $e){} } if(!empty($data['description'])) $product->set_description($data['description']); if(!empty($data['short_description'])) $product->set_short_description($data['short_description']); $pid=$product->save(); update_post_meta($pid,self::META_SRC_URL,esc_url_raw($data['source_url'])); if(!empty($opts['upload_images']) && (!$id || !empty($opts['refresh_images']))){ $imgs=[]; if(!empty($data['main_image']))$imgs=array_merge($imgs,(array)$data['main_image']); if(!empty($data['gallery']))$imgs=array_merge($imgs,(array)$data['gallery']); $ids=[]; foreach(array_unique($imgs) as $img){ $aid=$this->sideload($img,$pid); if($aid)$ids[]=$aid; } if($ids){ set_post_thumbnail($pid,$ids[0]); if(count($ids)>1) update_post_meta($pid,'_product_image_gallery',implode(',',array_slice($ids,1))); } } return $pid; }
    private function sideload($url,$post_id){ require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/image.php'; $existing=get_posts(['post_type'=>'attachment','post_status'=>'inherit','meta_key'=>self::META_SRC_URL,'meta_value'=>$url,'fields'=>'ids','posts_per_page'=>1]); if($existing)return $existing[0]; $tmp=download_url($url,25); if(is_wp_error($tmp))return 0; $name=basename(parse_url($url,PHP_URL_PATH))?:'image.jpg'; $file=['name'=>sanitize_file_name($name),'tmp_name'=>$tmp]; $id=media_handle_sideload($file,$post_id); if(is_wp_error($id)){ @unlink($tmp); return 0; } update_post_meta($id,self::META_SRC_URL,esc_url_raw($url)); return $id; }
    public function ajax_csv_download(){ if(!current_user_can('manage_woocommerce')&&!current_user_can('manage_options')) wp_die('no'); check_ajax_referer(self::NONCE,'nonce'); $job=sanitize_key($_GET['job']??''); $jobs=get_option(self::OPT_JOBS,[]); if(empty($jobs[$job])) wp_die('job not found'); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=wsp-products-'.$job.'.csv'); $out=fopen('php://output','w'); fputcsv($out,['Type','SKU','Name','Published','Visibility in catalog','Short description','Description','Regular price','Sale price','Categories','Tags','Images','Attribute 1 name','Attribute 1 value(s)','Attribute 1 visible','Attribute 1 global','Meta: source_url']); foreach($jobs[$job]['rows'] as $r){ $imgs=array_merge((array)($r['main_image']??[]),(array)($r['gallery']??[])); fputcsv($out,['simple',$r['sku']??'',$r['name']??'',0,'visible',$r['short_description']??'',$r['description']??'',$r['regular_price']??'',$r['sale_price']??'','','',implode(', ',$imgs),'Характеристики',implode(' | ',(array)($r['attributes']??[])),1,0,$r['source_url']??'']); } exit; }
    public function ajax_proxy_picker(){
        $this->check();
        $url=$this->safe_url($_GET['url']??'');
        if(!$url) wp_die('Bad URL');
        $html=$this->fetch($url);
        if(is_wp_error($html)) wp_die(esc_html($html->get_error_message()));
        echo '<base href="'.esc_url($url).'">';
        echo '<style>#wsp3-picker-panel{position:fixed;left:10px;right:10px;bottom:10px;z-index:2147483647;background:#fff;border:2px solid #2271b1;border-radius:12px;padding:10px;box-shadow:0 8px 30px rgba(0,0,0,.25);font-family:Arial,sans-serif;font-size:14px;color:#111}#wsp3-picker-panel select,#wsp3-picker-panel button{font-size:16px;padding:8px;margin:4px 2px}#wsp3-picked-info{display:block;margin-top:6px;word-break:break-all}.wsp3picked{outline:4px solid #2271b1!important;background:rgba(34,113,177,.16)!important}body *:not(#wsp3-picker-panel):not(#wsp3-picker-panel *){cursor:crosshair!important}</style>';
        echo '<div id="wsp3-picker-panel"><b>Woo Smart Parser: вибір поля</b><br><select id="wsp3-field"><option value="name">Назва</option><option value="regular_price">Ціна</option><option value="sale_price">Акційна ціна</option><option value="description">Опис</option><option value="short_description">Короткий опис</option><option value="main_image">Головне фото</option><option value="gallery">Галерея</option><option value="sku">Артикул / SKU</option><option value="attributes">Характеристики</option></select><button id="wsp3-save-picked" type="button">Додати поле</button><button id="wsp3-close-picked" type="button">Закрити</button><span id="wsp3-picked-info">Натисни на потрібний елемент товару, потім “Додати поле”.</span></div>';
        echo $html;
        echo "<script>(function(){let picked='';function cssEsc(v){return (window.CSS&&CSS.escape)?CSS.escape(v):String(v).replace(/[^a-zA-Z0-9_-]/g,'\\$&')}function cssPath(el){if(!el||!el.tagName)return ''; if(el.id)return '#'+cssEsc(el.id); let path=[]; while(el&&el.nodeType===1&&el.tagName.toLowerCase()!=='html'&&path.length<5){let part=el.tagName.toLowerCase(); if(el.className&&typeof el.className==='string'){let cls=el.className.trim().split(/\s+/).filter(Boolean).slice(0,2); if(cls.length)part+='.'+cls.map(cssEsc).join('.');} path.unshift(part); el=el.parentElement;} return path.join(' > ');}document.addEventListener('click',function(e){let panel=document.getElementById('wsp3-picker-panel'); if(panel&&panel.contains(e.target))return; e.preventDefault();e.stopPropagation();let el=e.target;document.querySelectorAll('.wsp3picked').forEach(x=>x.classList.remove('wsp3picked'));el.classList.add('wsp3picked');picked=cssPath(el);let t=(el.innerText||el.getAttribute('content')||el.src||el.href||'').trim().slice(0,140);document.getElementById('wsp3-picked-info').textContent='Вибрано: '+picked+(t?' → '+t:'');},true);document.getElementById('wsp3-save-picked').addEventListener('click',function(e){e.preventDefault();if(!picked){alert('Спочатку натисни на елемент товару');return;}let field=document.getElementById('wsp3-field').value; if(window.opener){window.opener.postMessage({wsp3Selector:picked,wsp3Field:field},'*'); alert('Додано поле. Можеш вибрати ще одне або закрити вікно.');}else{alert('Не бачу батьківське вікно. Спробуй вимкнути блокування popup.');}});document.getElementById('wsp3-close-picked').addEventListener('click',function(){window.close();});})();</script>";
        exit;
    }

}
new WSP3();
