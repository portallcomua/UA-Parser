<?php
/**
 * Plugin Name: Woo Smart Parser Pro - Visual Scraper
 * Plugin URI:  https://your-site.com/woo-smart-parser
 * Description: Візуальний парсер товарів з будь-якого сайту в WooCommerce. Клікайте на елементи - плагін сам збере селектори!
 * Version:     4.0.0
 * Author:      Your Name
 * Text Domain: woo-smart-parser
 * License:     GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WSP_VERSION', '4.0.0');
define('WSP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WSP_PLUGIN_URL', plugin_dir_url(__FILE__));

class WooSmartParserPro {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_wsp_proxy', [$this, 'ajax_proxy']);
        add_action('wp_ajax_wsp_test_parse', [$this, 'ajax_test_parse']);
        add_action('wp_ajax_wsp_save_template', [$this, 'ajax_save_template']);
        add_action('wp_ajax_wsp_load_template', [$this, 'ajax_load_template']);
        add_action('wp_ajax_wsp_delete_template', [$this, 'ajax_delete_template']);
        add_action('wp_ajax_wsp_start_parse', [$this, 'ajax_start_parse']);
    }
    
    public function add_admin_menu() {
        add_menu_page('Візуальний Парсер', 'Візуальний Парсер', 'manage_options', 'visual-scraper', [$this, 'admin_page'], 'dashicons-visibility', 80);
    }
    
    public function enqueue_scripts($hook) {
        if ($hook != 'toplevel_page_visual-scraper') return;
        wp_enqueue_script('wsp-script', WSP_PLUGIN_URL . 'script.js', ['jquery'], WSP_VERSION, true);
        wp_localize_script('wsp-script', 'wsp_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wsp_ajax_nonce')
        ]);
        wp_enqueue_style('wsp-style', WSP_PLUGIN_URL . 'style.css', [], WSP_VERSION);
    }
    
    public function admin_page() {
        $templates = get_option('wsp_templates', []);
        ?>
        <div class="wrap">
            <h1>🎯 Візуальний Парсер v4.0</h1>
            <p>Просто клікайте на елементи сайту — плагін сам збере селектори!</p>
            
            <!-- ШАБЛОНИ -->
            <div class="wsp-card">
                <h2>📁 Шаблони сайтів</h2>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:15px;">
                    <select id="template-select" style="min-width:200px;">
                        <option value="">-- Виберіть шаблон --</option>
                        <?php foreach ($templates as $key => $template): ?>
                            <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($template['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button id="template-load" class="button">📂 Завантажити</button>
                    <button id="template-save" class="button button-primary">💾 Зберегти шаблон</button>
                    <button id="template-delete" class="button" style="background:#dc3232; color:white;">🗑️ Видалити</button>
                </div>
                <div id="template-name-area" style="display:none; margin-top:10px;">
                    <input type="text" id="template-name" placeholder="Назва шаблону (наприклад: Kasta.ua)" style="width:300px">
                    <button id="template-save-confirm" class="button button-primary">Підтвердити</button>
                </div>
            </div>
            
            <!-- ВВЕДЕННЯ URL -->
            <div class="wsp-card">
                <h2>🔗 Крок 1: Введіть URL товару</h2>
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <input type="url" id="target-url" class="wsp-input" style="flex:3" placeholder="https://example.com/product/tea-pot" value="<?php echo isset($_GET['url']) ? esc_url($_GET['url']) : ''; ?>">
                    <button id="load-site-btn" class="button button-primary">🖼️ Завантажити сайт</button>
                    <button id="reset-selectors" class="button">🧹 Очистити селектори</button>
                </div>
            </div>
            
            <!-- КНОПКИ ПОЛІВ (з'являються після завантаження) -->
            <div class="wsp-card" id="fields-card" style="display:none;">
                <h2>🎯 Крок 2: Клікайте на елементи сайту</h2>
                <p><strong>Інструкція:</strong> Натисніть кнопку поля, потім КЛІКНІТЬ на потрібний елемент на сайті</p>
                
                <div id="field-buttons" style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px;">
                    <button class="field-btn button" data-field="title">🏷️ Назва</button>
                    <button class="field-btn button" data-field="price">💰 Ціна</button>
                    <button class="field-btn button" data-field="sale_price">🏷️ Акційна ціна</button>
                    <button class="field-btn button" data-field="description">📝 Опис</button>
                    <button class="field-btn button" data-field="image">🖼️ Головне фото</button>
                    <button class="field-btn button" data-field="sku">🔢 Артикул</button>
                    <button class="field-btn button" data-field="brand">🏷️ Бренд</button>
                </div>
                
                <div id="dynamic-fields"></div>
                <button id="add-dynamic-field" class="button">➕ Додати свою характеристику</button>
                
                <!-- Таблиця вибраних селекторів -->
                <div id="selectors-table" style="margin-top:20px;"></div>
                
                <!-- Селектор посилань на товари -->
                <div style="margin-top:20px; padding:15px; background:#f5f5f5; border-radius:4px;">
                    <label><strong>🔗 Селектор посилань на товари (на сторінці категорії):</strong></label>
                    <input type="text" id="product-link-selector" style="width:100%; margin-top:5px;" value="a[href*='/product/']" placeholder="a.product-link, .product-item a, a[href*='/product/']">
                    <p class="description">Цей селектор потрібен для збору всіх товарів з категорій</p>
                </div>
            </div>
            
            <!-- ТЕСТОВИЙ ПАРСИНГ -->
            <div class="wsp-card" id="test-card" style="display:none;">
                <h2>🔍 Крок 3: Перевірка селекторів</h2>
                <button id="test-parse-btn" class="button button-primary">⚡ Перевірити збір даних</button>
                <div id="test-result" style="margin-top:20px;"></div>
            </div>
            
            <!-- ЗАПУСК ПАРСИНГУ -->
            <div class="wsp-card" id="parse-card" style="display:none;">
                <h2>🚀 Крок 4: URL магазину та запуск</h2>
                <input type="url" id="site-url" class="wsp-input" style="width:100%" placeholder="https://example.com/">
                <div style="margin:15px 0;">
                    <label><input type="checkbox" id="create_csv" checked> 📄 Створити CSV файл</label><br>
                    <label><input type="checkbox" id="import_to_shop" checked> 🛒 Імпортувати в WooCommerce</label><br>
                    <label><input type="checkbox" id="import_as_draft" checked> 📝 Додавати як чернетки</label>
                </div>
                <button id="start-parse-btn" class="button button-primary button-large">🚀 Почати парсинг всього магазину</button>
                <div id="parse-progress" style="margin-top:20px;"></div>
                <div id="csv-download" style="margin-top:15px;"></div>
            </div>
            
            <!-- IFRAME ДЛЯ САЙТУ -->
            <div class="wsp-card" id="iframe-card" style="display:none;">
                <h2>🌐 Сайт для вибору селекторів:</h2>
                <div style="border: 3px solid #0073aa; background: #fff; height: 550px; overflow: hidden; border-radius: 5px;">
                    <iframe id="scraper-iframe" style="width: 100%; height: 100%; border: none;"></iframe>
                </div>
                <p class="description">💡 Клікайте на елементи після вибору поля вище</p>
            </div>
        </div>
        <?php
    }
    
    // ==================== ПРОКСІ ДЛЯ ЗАВАНТАЖЕННЯ САЙТУ ====================
    
    public function ajax_proxy() {
        if (!current_user_can('manage_options')) wp_die('Access denied');
        
        $url = isset($_GET['url']) ? esc_url_raw(urldecode($_GET['url'])) : '';
        if (empty($url)) wp_die('No URL');
        
        // Отримуємо HTML через cURL з хорошим User-Agent
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            CURLOPT_HEADER => true,
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        
        if ($http_code !== 200) {
            wp_die("HTTP код помилки: $http_code");
        }
        
        $headers = substr($response, 0, $header_size);
        $html = substr($response, $header_size);
        
        // Видаляємо заголовки безпеки, що блокують iframe
        $html = preg_replace('/<meta[^>]*Content-Security-Policy[^>]*>/i', '', $html);
        $html = preg_replace('/<meta[^>]*X-Frame-Options[^>]*>/i', '', $html);
        
        // Додаємо скрипт для візуального вибору
        $script = $this->get_visual_selector_script();
        $html = str_replace('</body>', $script . '</body>', $html);
        
        // Дозволяємо iframe
        header('X-Frame-Options: ALLOWALL');
        header('Content-Security-Policy: frame-ancestors *');
        
        echo $html;
        exit;
    }
    
    private function get_visual_selector_script() {
        return '
        <script>
        (function() {
            let lastHover = null;
            
            function getSimpleSelector(el) {
                if (!el || !el.nodeType) return "";
                if (el.id) return "#" + el.id;
                if (el.classList && el.classList.length) {
                    for (let c of el.classList) {
                        if (c && !c.match(/^\\d/) && c.length > 2 && c.length < 40) {
                            return "." + c;
                        }
                    }
                }
                let name = el.tagName.toLowerCase();
                if (el.parentNode) {
                    let siblings = el.parentNode.children;
                    let idx = 1;
                    for (let s of siblings) {
                        if (s.tagName === el.tagName) {
                            if (s === el) break;
                            idx++;
                        }
                    }
                    return name + ":nth-child(" + idx + ")";
                }
                return name;
            }
            
            function getElementInfo(el) {
                let selector = getSimpleSelector(el);
                let text = (el.innerText || "").trim().substring(0, 100);
                let tag = el.tagName.toLowerCase();
                return { selector: selector, text: text, tag: tag };
            }
            
            document.body.addEventListener("mouseover", function(e) {
                if (lastHover) lastHover.style.outline = "";
                e.target.style.outline = "3px solid #ff6600";
                e.target.style.cursor = "pointer";
                lastHover = e.target;
            });
            
            document.body.addEventListener("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                let info = getElementInfo(e.target);
                window.parent.postMessage({ 
                    action: "selector_selected", 
                    selector: info.selector, 
                    text: info.text, 
                    tag: info.tag 
                }, "*");
                e.target.style.outline = "3px solid #00aa00";
                setTimeout(function() { e.target.style.outline = ""; }, 500);
            }, true);
            
            // Для мобільних пристроїв
            document.body.addEventListener("touchstart", function(e) {
                if (lastHover) lastHover.style.outline = "";
                let touch = e.touches[0];
                let el = document.elementFromPoint(touch.clientX, touch.clientY);
                if (el) el.style.outline = "3px solid #ff6600";
                lastHover = el;
            }, { passive: true });
            
            document.body.addEventListener("touchend", function(e) {
                e.preventDefault();
                if (lastHover) {
                    let info = getElementInfo(lastHover);
                    window.parent.postMessage({ 
                        action: "selector_selected", 
                        selector: info.selector, 
                        text: info.text, 
                        tag: info.tag 
                    }, "*");
                    lastHover.style.outline = "3px solid #00aa00";
                    setTimeout(function() { if(lastHover) lastHover.style.outline = ""; }, 500);
                }
            }, true);
            
            console.log("✅ Візуальний вибір активовано! Клікайте на будь-який елемент.");
        })();
        </script>
        <style>
            body * { transition: outline 0.1s ease; }
        </style>
        ';
    }
    
    // ==================== ТЕСТОВИЙ ПАРСИНГ ====================
    
    public function ajax_test_parse() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        
        $url = sanitize_text_field($_POST['url']);
        $selectors = $_POST['selectors'];
        
        $html = $this->get_html($url);
        if (!$html) {
            wp_send_json_error('Не вдалося завантажити сторінку');
        }
        
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $result = [];
        foreach ($selectors as $field => $selector) {
            if (empty($selector)) {
                $result[$field] = '⏭ пропущено';
                continue;
            }
            
            try {
                if ($field == 'image') {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $src = $nodes->item(0)->getAttribute('src') ?: $nodes->item(0)->getAttribute('data-src');
                        $result[$field] = $src ? '✅ ' . substr($src, 0, 80) : '❌ немає src';
                    } else {
                        $result[$field] = '❌ не знайдено';
                    }
                } elseif ($field == 'gallery') {
                    $nodes = $xpath->query($selector);
                    $result[$field] = ($nodes && $nodes->length) ? '✅ знайдено ' . $nodes->length . ' фото' : '❌ не знайдено';
                } else {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $value = trim(strip_tags($nodes->item(0)->textContent));
                        $result[$field] = $value ? '✅ ' . mb_substr($value, 0, 100) : '❌ порожнє';
                    } else {
                        $result[$field] = '❌ не знайдено';
                    }
                }
            } catch (Exception $e) {
                $result[$field] = '❌ помилка: ' . $e->getMessage();
            }
        }
        
        wp_send_json_success($result);
    }
    
    // ==================== ШАБЛОНИ ====================
    
    public function ajax_save_template() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        $name = sanitize_text_field($_POST['name']);
        $selectors = $_POST['selectors'];
        $product_link = sanitize_text_field($_POST['product_link']);
        
        $templates = get_option('wsp_templates', []);
        $key = sanitize_title($name);
        $templates[$key] = [
            'name' => $name,
            'selectors' => $selectors,
            'product_link' => $product_link,
            'updated' => current_time('mysql')
        ];
        update_option('wsp_templates', $templates);
        wp_send_json_success();
    }
    
    public function ajax_load_template() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        $key = sanitize_text_field($_POST['key']);
        $templates = get_option('wsp_templates', []);
        if (isset($templates[$key])) {
            wp_send_json_success($templates[$key]);
        } else {
            wp_send_json_error('Шаблон не знайдено');
        }
    }
    
    public function ajax_delete_template() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        $key = sanitize_text_field($_POST['key']);
        $templates = get_option('wsp_templates', []);
        if (isset($templates[$key])) {
            unset($templates[$key]);
            update_option('wsp_templates', $templates);
            wp_send_json_success();
        } else {
            wp_send_json_error('Шаблон не знайдено');
        }
    }
    
    // ==================== ПАРСИНГ ВСЬОГО МАГАЗИНУ ====================
    
    public function ajax_start_parse() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        set_time_limit(180);
        
        $site_url = sanitize_url($_POST['site_url']);
        $selectors = $_POST['selectors'];
        $product_link = sanitize_text_field($_POST['product_link']);
        $create_csv = $_POST['create_csv'] === 'true';
        $import = $_POST['import_to_shop'] === 'true';
        $as_draft = $_POST['as_draft'] === 'true';
        
        $urls = $this->get_all_product_urls($site_url, $product_link);
        
        if (empty($urls)) {
            wp_send_json_error('Не знайдено жодного товару. Перевірте селектор посилань.');
        }
        
        $products = [];
        $total = 0;
        
        foreach ($urls as $url) {
            $total++;
            $data = $this->parse_product($url, $selectors);
            if ($data && !empty($data['title'])) {
                $products[] = $data;
                if ($import) {
                    $this->import_to_wc($data, $as_draft);
                }
            }
            if ($total >= 50) break;
            sleep(1);
        }
        
        $result = ['total' => count($products)];
        
        if ($create_csv && !empty($products)) {
            $csv_url = $this->generate_csv($products);
            $result['csv_url'] = $csv_url;
        }
        
        wp_send_json_success($result);
    }
    
    private function get_html($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        ]);
        $html = curl_exec($ch);
        curl_close($ch);
        return $html;
    }
    
    private function get_all_product_urls($site_url, $link_selector) {
        $all = [];
        $categories = $this->get_categories($site_url);
        foreach ($categories as $cat) {
            $urls = $this->get_urls_from_category($cat, $link_selector);
            $all = array_merge($all, $urls);
        }
        return array_unique($all);
    }
    
    private function get_categories($site_url) {
        $html = $this->get_html($site_url);
        if (!$html) return [$site_url];
        
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $patterns = [
            '//a[contains(@href, "/category/")]',
            '//a[contains(@href, "/catalog/")]',
            '//a[contains(@href, "/product-category/")]',
            '//a[contains(@class, "category")]'
        ];
        
        $urls = [];
        foreach ($patterns as $pattern) {
            $nodes = $xpath->query($pattern);
            foreach ($nodes as $node) {
                $href = $node->getAttribute('href');
                if ($href && strpos($href, $site_url) !== false) {
                    $urls[] = $href;
                }
            }
        }
        return array_unique($urls) ?: [$site_url];
    }
    
    private function get_urls_from_category($cat_url, $selector) {
        $urls = [];
        $current = $cat_url;
        $page = 0;
        
        while ($current && $page < 20) {
            $html = $this->get_html($current);
            if (!$html) break;
            
            $dom = new DOMDocument();
            @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
            $xpath = new DOMXPath($dom);
            
            $nodes = $xpath->query($selector);
            foreach ($nodes as $node) {
                $href = $node->getAttribute('href');
                if ($href) {
                    if (filter_var($href, FILTER_VALIDATE_URL)) {
                        $urls[] = $href;
                    } else {
                        $urls[] = rtrim($current, '/') . '/' . ltrim($href, '/');
                    }
                }
            }
            
            $next = $xpath->query('//a[contains(@class, "next")] | //a[contains(text(), "»")] | //a[contains(text(), "Next")]');
            $current = $next->length ? $next->item(0)->getAttribute('href') : null;
            $page++;
        }
        return $urls;
    }
    
    private function parse_product($url, $selectors) {
        $html = $this->get_html($url);
        if (!$html) return null;
        
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $data = ['url' => $url];
        foreach ($selectors as $field => $selector) {
            if (empty($selector)) continue;
            
            try {
                if ($field == 'image') {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $src = $nodes->item(0)->getAttribute('src') ?: $nodes->item(0)->getAttribute('data-src');
                        $data[$field] = $src;
                    }
                } elseif ($field == 'gallery') {
                    $data[$field] = [];
                    $nodes = $xpath->query($selector);
                    foreach ($nodes as $img) {
                        $src = $img->getAttribute('src') ?: $img->getAttribute('data-src');
                        if ($src) $data[$field][] = $src;
                    }
                } else {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $data[$field] = trim(strip_tags($nodes->item(0)->textContent));
                    }
                }
            } catch (Exception $e) {}
        }
        return $data;
    }
    
    private function generate_csv($products) {
        if (empty($products)) return false;
        
        $upload_dir = wp_upload_dir();
        $csv_dir = $upload_dir['basedir'] . '/wsp-csv/';
        if (!file_exists($csv_dir)) mkdir($csv_dir, 0777, true);
        
        $filename = 'products_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = $csv_dir . $filename;
        
        $headers = array_keys($products[0]);
        $file = fopen($filepath, 'w');
        fputcsv($file, $headers);
        
        foreach ($products as $product) {
            $row = [];
            foreach ($headers as $header) {
                $value = $product[$header] ?? '';
                if (is_array($value)) $value = implode('|', $value);
                $row[] = $value;
            }
            fputcsv($file, $row);
        }
        fclose($file);
        
        return $upload_dir['baseurl'] . '/wsp-csv/' . $filename;
    }
    
    private function import_to_wc($data, $as_draft = false) {
        if (!class_exists('WooCommerce')) return false;
        
        $post_status = $as_draft ? 'draft' : 'publish';
        $price = floatval(preg_replace('/[^0-9.]/', '', $data['price'] ?? '0'));
        
        $product_id = wp_insert_post([
            'post_title' => $data['title'] ?? 'Без назви',
            'post_content' => $data['description'] ?? '',
            'post_type' => 'product',
            'post_status' => $post_status,
            'meta_input' => [
                '_regular_price' => $price,
                '_price' => $price
            ]
        ]);
        
        if (!empty($data['image']) && $product_id) {
            $attach_id = $this->upload_image($data['image']);
            if ($attach_id) set_post_thumbnail($product_id, $attach_id);
        }
        
        return $product_id;
    }
    
    private function upload_image($url) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        
        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) return false;
        
        $file_array = ['name' => basename(parse_url($url, PHP_URL_PATH)), 'tmp_name' => $tmp];
        $attach_id = media_handle_sideload($file_array, 0);
        
        @unlink($tmp);
        return is_wp_error($attach_id) ? false : $attach_id;
    }
}

new WooSmartParserPro();