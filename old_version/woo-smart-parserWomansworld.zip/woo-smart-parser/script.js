jQuery(document).ready(function($) {
    
    var currentSelectors = {};
    var dynamicFieldCount = 0;
    var currentUrl = '';
    
    // ==================== ЗАВАНТАЖЕННЯ САЙТУ ====================
    
    $('#load-site-btn').click(function() {
        var url = $('#target-url').val();
        if (!url) {
            alert('Введіть URL товару');
            return;
        }
        currentUrl = url;
        
        $('#iframe-card').show();
        $('#fields-card').show();
        
        var proxyUrl = wsp_ajax.ajax_url + '?action=wsp_proxy&url=' + encodeURIComponent(url);
        $('#scraper-iframe').attr('src', proxyUrl);
        
        $('#load-site-btn').text('🔄 Перезавантажити');
    });
    
    // ==================== ОТРИМАННЯ СЕЛЕКТОРІВ З IFRAME ====================
    
    window.addEventListener('message', function(event) {
        if (event.data && event.data.action === 'selector_selected') {
            var activeField = $('.field-btn.active').data('field');
            if (!activeField) {
                alert('Спочатку натисніть кнопку поля (Назва, Ціна тощо)');
                return;
            }
            
            var selector = event.data.selector;
            var text = event.data.text;
            
            // Зберігаємо селектор
            currentSelectors[activeField] = {
                selector: selector,
                example: text,
                label: $('.field-btn.active').text().trim()
            };
            
            renderSelectorsTable();
            
            // Підсвічуємо успішний вибір
            var btn = $('.field-btn.active');
            btn.css('background', '#4caf50').css('color', 'white');
            setTimeout(function() { btn.css('background', '').css('color', ''); }, 500);
            
            $('.field-btn.active').removeClass('active');
            
            $('#test-card').show();
        }
    });
    
    // ==================== КНОПКИ ПОЛІВ ====================
    
    $(document).on('click', '.field-btn', function() {
        $('.field-btn').removeClass('active');
        $(this).addClass('active');
        
        var field = $(this).data('field');
        var label = $(this).text();
        
        $('#test-result').html('<div class="notice notice-info">🔍 Клікніть на елемент "' + label + '" на сайті</div>');
    });
    
    // ==================== ДИНАМІЧНІ ХАРАКТЕРИСТИКИ ====================
    
    $('#add-dynamic-field').click(function() {
        dynamicFieldCount++;
        var fieldId = 'dynamic_' + dynamicFieldCount;
        
        var html = '<div class="dynamic-field-item" style="display:flex; gap:10px; margin-bottom:10px; align-items:center;">';
        html += '<input type="text" class="dynamic-field-name" placeholder="Назва (напр. Колір)" style="width:150px;">';
        html += '<button class="field-btn button" data-field="' + fieldId + '">🎯 Вибрати значення</button>';
        html += '<span class="dynamic-selector-display" style="color:#666; font-size:11px;">(не вибрано)</span>';
        html += '<button class="remove-dynamic-field button" style="color:red;">✕</button>';
        html += '<input type="hidden" class="dynamic-selector-value" value="">';
        html += '</div>';
        
        $('#dynamic-fields').append(html);
    });
    
    $(document).on('click', '.remove-dynamic-field', function() {
        $(this).closest('.dynamic-field-item').remove();
    });
    
    $(document).on('click', '.field-btn', function() {
        var btn = $(this);
        if (btn.data('field') && btn.data('field').toString().startsWith('dynamic_')) {
            $('.field-btn').removeClass('active');
            btn.addClass('active');
            
            var fieldId = btn.data('field');
            var fieldName = btn.closest('.dynamic-field-item').find('.dynamic-field-name').val() || 'Характеристика';
            
            $('#test-result').html('<div class="notice notice-info">🔍 Клікніть на значення "' + fieldName + '" на сайті</div>');
            
            // Тимчасово зберігаємо для чого клік
            window.pendingDynamicField = {
                id: fieldId,
                btn: btn
            };
        }
    });
    
    // Обробка вибору для динамічних полів
    window.addEventListener('message', function(event) {
        if (event.data && event.data.action === 'selector_selected' && window.pendingDynamicField) {
            var fieldId = window.pendingDynamicField.id;
            var selector = event.data.selector;
            var text = event.data.text;
            
            var item = $('.dynamic-field-item').has('button[data-field="' + fieldId + '"]');
            item.find('.dynamic-selector-display').text('✅ ' + text.substring(0, 40));
            item.find('.dynamic-selector-value').val(selector);
            
            var fieldName = item.find('.dynamic-field-name').val() || 'Характеристика';
            var cleanName = fieldName.toLowerCase().replace(/\s/g, '_');
            
            currentSelectors[cleanName] = {
                selector: selector,
                example: text,
                label: fieldName
            };
            
            renderSelectorsTable();
            
            window.pendingDynamicField = null;
            $('.field-btn').removeClass('active');
            
            $('#test-card').show();
        }
    });
    
    // ==================== ТАБЛИЦЯ СЕЛЕКТОРІВ ====================
    
    function renderSelectorsTable() {
        if (Object.keys(currentSelectors).length === 0) {
            $('#selectors-table').html('<p>Немає вибраних селекторів. Натисніть кнопку поля і клікніть на елемент сайту.</p>');
            return;
        }
        
        var html = '<h3>📋 Вибрані селектори:</h3><table class="wsp-table"><thead></td><th width="20%">Поле</th><th width="50%">Селектор</th><th width="20%">Приклад</th><th width="10%"></th></thead><tbody>';
        
        for (var field in currentSelectors) {
            var sel = currentSelectors[field];
            html += '<tr data-field="' + field + '">';
            html += '<td><strong>' + (sel.label || field) + '</strong></td>';
            html += '<td><input type="text" class="selector-edit" data-field="' + field + '" value="' + escapeHtml(sel.selector) + '" style="width:100%;font-family:monospace;"></td>';
            html += '<td>' + escapeHtml(sel.example || '') + '</td>';
            html += '<td><button class="remove-selector" data-field="' + field + '" style="background:none;border:none;color:#dc3232;cursor:pointer;">❌</button></td>';
            html += '</tr>';
        }
        html += '</tbody></table>';
        
        $('#selectors-table').html(html);
        
        $('.selector-edit').on('input', function() {
            var field = $(this).data('field');
            currentSelectors[field].selector = $(this).val();
        });
        
        $('.remove-selector').click(function() {
            var field = $(this).data('field');
            delete currentSelectors[field];
            renderSelectorsTable();
        });
    }
    
    // ==================== ТЕСТОВИЙ ПАРСИНГ ====================
    
    $('#test-parse-btn').click(function() {
        if (Object.keys(currentSelectors).length === 0) {
            alert('Спочатку виберіть селектори');
            return;
        }
        
        var url = $('#target-url').val();
        $('#test-result').html('<div class="notice notice-info">🔍 Перевірка селекторів...</div>');
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_test_parse',
            url: url,
            selectors: currentSelectors,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                var html = '<div class="notice notice-success">✅ Результати перевірки:</div><table class="wsp-table"><thead><tr><th>Поле</th><th>Значення</th></tr></thead><tbody>';
                for (var field in res.data) {
                    html += '<tr><td><strong>' + field + '</strong></td><td>' + escapeHtml(res.data[field]) + '</td></tr>';
                }
                html += '</tbody></table>';
                $('#test-result').html(html);
                $('#parse-card').show();
            } else {
                $('#test-result').html('<div class="notice notice-error">❌ ' + (res.data || 'Помилка') + '</div>');
            }
        });
    });
    
    // ==================== ШАБЛОНИ ====================
    
    $('#template-save').click(function() {
        if (Object.keys(currentSelectors).length === 0) {
            alert('Спочатку виберіть селектори');
            return;
        }
        $('#template-name-area').show();
    });
    
    $('#template-save-confirm').click(function() {
        var name = $('#template-name').val();
        if (!name) {
            alert('Введіть назву шаблону');
            return;
        }
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_save_template',
            name: name,
            selectors: currentSelectors,
            product_link: $('#product-link-selector').val(),
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                alert('✅ Шаблон "' + name + '" збережено!');
                location.reload();
            } else {
                alert('❌ Помилка збереження');
            }
        });
    });
    
    $('#template-load').click(function() {
        var key = $('#template-select').val();
        if (!key) {
            alert('Виберіть шаблон');
            return;
        }
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_load_template',
            key: key,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                currentSelectors = res.data.selectors;
                $('#product-link-selector').val(res.data.product_link);
                renderSelectorsTable();
                $('#test-card').show();
                $('#parse-card').show();
                $('#fields-card').show();
                $('#test-result').html('<div class="notice notice-success">✅ Завантажено шаблон: ' + res.data.name + '</div>');
            } else {
                alert('❌ Помилка завантаження');
            }
        });
    });
    
    $('#template-delete').click(function() {
        var key = $('#template-select').val();
        if (!key || !confirm('Видалити шаблон?')) return;
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_delete_template',
            key: key,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                alert('✅ Шаблон видалено');
                location.reload();
            }
        });
    });
    
    $('#reset-selectors').click(function() {
        if (confirm('Очистити всі вибрані селектори?')) {
            currentSelectors = {};
            renderSelectorsTable();
            $('#test-card').hide();
            $('#parse-card').hide();
        }
    });
    
    // ==================== ЗАПУСК ПАРСИНГУ ====================
    
    $('#start-parse-btn').click(function() {
        if (Object.keys(currentSelectors).length === 0) {
            alert('Спочатку виберіть селектори');
            return;
        }
        
        var siteUrl = $('#site-url').val();
        if (!siteUrl) {
            alert('Введіть URL магазину');
            return;
        }
        
        $('#parse-progress').html('<div class="notice notice-info">🚀 Парсинг запущено...<div class="spinner is-active" style="float:none"></div></div>');
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_start_parse',
            site_url: siteUrl,
            selectors: currentSelectors,
            product_link: $('#product-link-selector').val(),
            create_csv: $('#create_csv').is(':checked'),
            import_to_shop: $('#import_to_shop').is(':checked'),
            as_draft: $('#import_as_draft').is(':checked'),
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                var html = '<div class="notice notice-success">✅ Готово! Оброблено ' + res.data.total + ' товарів.</div>';
                if (res.data.csv_url) {
                    html += '<a href="' + res.data.csv_url + '" class="button button-primary" download>📥 Завантажити CSV</a>';
                }
                $('#parse-progress').html(html);
            } else {
                $('#parse-progress').html('<div class="notice notice-error">❌ ' + (res.data || 'Помилка') + '</div>');
            }
        });
    });
    
    function escapeHtml(text) {
        if (!text) return '';
        return $('<div>').text(text).html();
    }
});