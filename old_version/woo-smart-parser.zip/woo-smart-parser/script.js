jQuery(document).ready(function($) {
    
    var currentSelectors = {};
    var currentProductUrl = '';
    
    // Авто-визначення
    $('#auto-detect-btn').click(function() {
        var url = $('#sample-url').val();
        if (!url) {
            alert('Введіть URL товару');
            return;
        }
        currentProductUrl = url;
        
        $('#detect-result').html('<div class="notice notice-info">🔍 Аналіз сторінки...</div>');
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_auto_detect',
            url: url,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (!res.success) {
                $('#detect-result').html('<div class="notice notice-error">❌ ' + (res.data || 'Помилка') + '</div>');
                return;
            }
            
            currentSelectors = res.data;
            renderSelectors(currentSelectors);
            $('#selectors-card').show();
            $('#detect-result').html('<div class="notice notice-success">✅ Знайдено селектори! Ви можете їх редагувати.</div>');
        });
    });
    
    // Ручний режим
    $('#manual-mode-btn').click(function() {
        var url = $('#sample-url').val();
        if (!url) {
            alert('Введіть URL товару');
            return;
        }
        currentProductUrl = url;
        currentSelectors = {
            title: {selector: '', example: ''},
            price: {selector: '', example: ''},
            description: {selector: '', example: ''},
            image: {selector: '', example: ''}
        };
        renderSelectors(currentSelectors, true);
        $('#selectors-card').show();
        $('#detect-result').html('<div class="notice notice-info">✏️ Ручний режим: введіть селектори вручну</div>');
    });
    
    function renderSelectors(selectors) {
        var html = '<table class="wsp-table">';
        html += '<thead><tr><th width="20%">Поле</th><th width="50%">Селектор (CSS/XPath)</th><th width="20%">Приклад</th><th width="10%"></th></tr></thead><tbody>';
        
        for (var field in selectors) {
            var value = selectors[field].selector || '';
            var example = selectors[field].example || '';
            html += '<tr data-field="' + field + '">';
            html += '<td><strong>' + getFieldLabel(field) + '</strong><br><small>' + field + '</small></td>';
            html += '<td><input type="text" class="selector-input" data-field="' + field + '" value="' + escapeHtml(value) + '" style="width:100%" placeholder="наприклад: .title  або  //h1"></td>';
            html += '<td class="example-cell">' + escapeHtml(example) + '</td>';
            html += '<td><button class="remove-field button-link" data-field="' + field + '">❌</button></td>';
            html += '</tr>';
        }
        
        html += '</tbody></table>';
        
        $('#selectors-list').html(html);
        
        $('.selector-input').on('input', function() {
            var field = $(this).data('field');
            currentSelectors[field].selector = $(this).val();
            currentSelectors[field].example = '';
            $(this).closest('tr').find('.example-cell').text('⏳ натисніть "Перевірити"');
        });
    }
    
    $('#add-field-btn').click(function() {
        var newField = prompt('Введіть назву нового поля (наприклад: color, size, brand):');
        if (newField && !currentSelectors[newField]) {
            currentSelectors[newField] = {selector: '', example: ''};
            renderSelectors(currentSelectors);
        } else if (newField) {
            alert('Таке поле вже існує');
        }
    });
    
    $(document).on('click', '.remove-field', function() {
        var field = $(this).data('field');
        if (confirm('Видалити поле "' + field + '"?')) {
            delete currentSelectors[field];
            renderSelectors(currentSelectors);
        }
    });
    
    // Перевірка селекторів
    $('#test-selectors-btn').click(function() {
        var selectorsToTest = {};
        $('.selector-input').each(function() {
            var field = $(this).data('field');
            var selector = $(this).val();
            if (selector) {
                selectorsToTest[field] = selector;
            }
        });
        
        if (Object.keys(selectorsToTest).length === 0) {
            alert('Введіть хоча б один селектор для перевірки');
            return;
        }
        
        $('#test-result').html('<div class="notice notice-info">🔍 Перевірка...</div>');
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_test_selectors',
            url: currentProductUrl,
            selectors: selectorsToTest,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (!res.success) {
                $('#test-result').html('<div class="notice notice-error">❌ ' + (res.data || 'Помилка') + '</div>');
                return;
            }
            
            var html = '<h3>📋 Результат перевірки:</h3><table class="wsp-table"><thead><tr><th>Поле</th><th>Значення</th></tr></thead><tbody>';
            for (var field in res.data) {
                html += '<tr><td><strong>' + getFieldLabel(field) + '</strong></td><td>' + escapeHtml(res.data[field]) + '</td></tr>';
            }
            html += '</tbody></table>';
            html += '<div class="notice notice-success">✅ Якщо всі значення правильні - переходьте до Кроку 3</div>';
            
            $('#test-result').html(html);
            $('#parse-card').show();
        });
    });
    
    // Старт парсингу
    $('#start-parse-btn').click(function() {
        var siteUrl = $('#site-url').val();
        if (!siteUrl) {
            alert('Введіть URL магазину');
            return;
        }
        
        var productLinkSelector = $('#product-link-selector').val() || 'a[href*="/product/"]';
        
        var selectorsToParse = {};
        $('.selector-input').each(function() {
            var field = $(this).data('field');
            var selector = $(this).val();
            if (selector) {
                selectorsToParse[field] = selector;
            }
        });
        
        var settings = {
            site_url: siteUrl,
            selectors: selectorsToParse,
            product_link_selector: productLinkSelector,
            create_csv: $('#create_csv').is(':checked'),
            import_to_shop: $('#import_to_shop').is(':checked'),
            as_draft: $('#import_as_draft').is(':checked')
        };
        
        $('#parse-progress').html('<div class="notice notice-info">🚀 Парсинг запущено...<div class="spinner is-active" style="float:none"></div></div>');
        
        $.post(wsp_ajax.ajax_url, {
            action: 'wsp_start_parse',
            site_url: settings.site_url,
            selectors: settings.selectors,
            product_link_selector: settings.product_link_selector,
            create_csv: settings.create_csv,
            import_to_shop: settings.import_to_shop,
            as_draft: settings.as_draft,
            nonce: wsp_ajax.nonce
        }, function(res) {
            if (res.success) {
                var html = '<div class="notice notice-success">✅ Готово! Оброблено ' + res.data.total + ' товарів.</div>';
                if (res.data.csv_url) {
                    html += '<a href="' + res.data.csv_url + '" class="button button-primary" download>📥 Завантажити CSV</a>';
                }
                $('#parse-progress').html(html);
            } else {
                $('#parse-progress').html('<div class="notice notice-error">❌ ' + (res.data || 'Помилка') + '</div>');
            }
        }).fail(function() {
            $('#parse-progress').html('<div class="notice notice-error">❌ Помилка з\'єднання. Спробуйте ще раз.</div>');
        });
    });
    
    function getFieldLabel(field) {
        var labels = {
            'title': 'Назва', 'price': 'Ціна', 'sale_price': 'Акційна ціна',
            'description': 'Опис', 'image': 'Фото', 'gallery': 'Галерея',
            'sku': 'Артикул', 'brand': 'Бренд', 'color': 'Колір', 'size': 'Розмір'
        };
        return labels[field] || field;
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        return $('<div>').text(text).html();
    }
});