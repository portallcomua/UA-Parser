<?php
/**
 * Plugin Name: Woo Smart Parser
 * Plugin URI:  https://your-site.com/woo-smart-parser
 * Description: Парсинг товарів з будь-якого сайту в WooCommerce
 * Version:     2.1.0
 * Author:      Your Name
 * Text Domain: woo-smart-parser
 * License:     GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WSP_VERSION', '2.1.0');
define('WSP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WSP_PLUGIN_URL', plugin_dir_url(__FILE__));

class WSP_Monetization {
    public function get_free_limit() {
        return 50;
    }
    
    public function is_license_active($license_key = '') {
        if (empty($license_key)) return false;
        return $license_key === 'TEST-KEY-12345';
    }
    
    public function can_import($current_count, $license_key = '') {
        if ($this->is_license_active($license_key)) return true;
        return $current_count <= $this->get_free_limit();
    }
}

class WooSmartParser {
    
    private $monetization;
    
    public function __construct() {
        $this->monetization = new WSP_Monetization();
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_wsp_auto_detect', [$this, 'ajax_auto_detect']);
        add_action('wp_ajax_wsp_test_selectors', [$this, 'ajax_test_selectors']);
        add_action('wp_ajax_wsp_start_parse', [$this, 'ajax_start_parse']);
    }
    
    public function add_admin_menu() {
        add_menu_page('Smart Parser', 'Smart Parser', 'manage_options', 'woo-smart-parser', [$this, 'admin_page'], 'dashicons-download', 30);
        add_submenu_page('woo-smart-parser', 'License', 'License', 'manage_options', 'woo-smart-parser-license', [$this, 'license_page']);
    }
    
    public function license_page() {
        if (isset($_POST['wsp_license_key']) && check_admin_referer('wsp_license_nonce')) {
            update_option('wsp_license_key', sanitize_text_field($_POST['wsp_license_key']));
            echo '<div class="notice notice-success"><p>Ліцензію збережено</p></div>';
        }
        $license_key = get_option('wsp_license_key', '');
        ?>
        <div class="wrap">
            <h1>Активація ліцензії</h1>
            <form method="post">
                <?php wp_nonce_field('wsp_license_nonce'); ?>
                <input type="text" name="wsp_license_key" value="<?php echo esc_attr($license_key); ?>" style="width:300px">
                <p>Безкоштовна версія: до <?php echo $this->monetization->get_free_limit(); ?> товарів.</p>
                <?php submit_button('Зберегти'); ?>
            </form>
        </div>
        <?php
    }
    
    public function enqueue_scripts($hook) {
        if ($hook != 'toplevel_page_woo-smart-parser') return;
        wp_enqueue_script('wsp-script', WSP_PLUGIN_URL . 'script.js', ['jquery'], WSP_VERSION, true);
        wp_localize_script('wsp-script', 'wsp_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wsp_ajax_nonce')
        ]);
        wp_enqueue_style('wsp-style', WSP_PLUGIN_URL . 'style.css', [], WSP_VERSION);
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Woo Smart Parser</h1>
            
            <div class="wsp-card">
                <h2>📌 Крок 1: Введіть URL товару (зразок)</h2>
                <input type="url" id="sample-url" class="wsp-input" style="width:100%" placeholder="https://example.com/product/tea-pot">
                <div style="margin-top:15px;">
                    <button id="auto-detect-btn" class="button button-primary">🔍 Авто-визначення</button>
                    <button id="manual-mode-btn" class="button">✏️ Ручний режим</button>
                </div>
                <div id="detect-result" style="margin-top:20px"></div>
            </div>

            <div class="wsp-card" id="selectors-card" style="display:none">
                <h2>📌 Крок 2: Налаштуйте селектори</h2>
                <div id="selectors-list"></div>
                <button id="add-field-btn" class="button">➕ Додати поле</button>
                <div style="margin-top:15px;">
                    <label>🔗 Селектор посилань на товари:</label>
                    <input type="text" id="product-link-selector" style="width:100%" placeholder="a[href*='/product/']  або  .product-item a" value="a[href*='/product/']">
                </div>
                <br>
                <button id="test-selectors-btn" class="button button-primary">🔍 Перевірити селектори</button>
                <div id="test-result" style="margin-top:20px"></div>
            </div>

            <div class="wsp-card" id="parse-card" style="display:none">
                <h2>📌 Крок 3: Введіть URL магазину та запустіть парсинг</h2>
                <input type="url" id="site-url" class="wsp-input" style="width:100%" placeholder="https://example.com/">
                <div style="margin:15px 0;">
                    <label><input type="checkbox" id="create_csv" checked> 📄 Створити CSV</label><br>
                    <label><input type="checkbox" id="import_to_shop" checked> 🛒 Імпорт в WooCommerce</label><br>
                    <label><input type="checkbox" id="import_as_draft" checked> 📝 Додавати як чернетки</label>
                </div>
                <button id="start-parse-btn" class="button button-primary button-large">🚀 Почати парсинг</button>
                <div id="parse-progress" style="margin-top:20px"></div>
                <div id="csv-download" style="margin-top:15px"></div>
            </div>
        </div>
        <?php
    }
    
    public function ajax_auto_detect() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        
        $url = sanitize_text_field($_POST['url']);
        
        // Перевірка доступності
        $headers = @get_headers($url);
        if (!$headers || strpos($headers[0], '200') === false) {
            wp_send_json_error('Сайт недоступний або блокує запити. Код: ' . ($headers[0] ?? 'невідомо'));
        }
        
        $html = $this->get_html($url);
        if (!$html) {
            wp_send_json_error('Не вдалося завантажити сторінку. Сайт може блокувати парсинг.');
        }
        
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $suggestions = [];
        
        // Назва
        $title_selectors = ['//h1', '//*[@class*="title"]', '//*[@itemprop="name"]', '//div[@class*="product-name"]//h1'];
        foreach ($title_selectors as $sel) {
            $nodes = $xpath->query($sel);
            if ($nodes && $nodes->length) {
                $text = trim(strip_tags($nodes->item(0)->textContent));
                if (strlen($text) > 3 && strlen($text) < 200) {
                    $suggestions['title'] = ['selector' => $sel, 'example' => $text];
                    break;
                }
            }
        }
        
        // Ціна
        $price_selectors = ['//*[@class*="price"]', '//*[@itemprop="price"]', '//span[contains(@class, "amount")]', '//span[contains(text(), "₴")]'];
        foreach ($price_selectors as $sel) {
            $nodes = $xpath->query($sel);
            if ($nodes && $nodes->length) {
                $text = trim(strip_tags($nodes->item(0)->textContent));
                if (preg_match('/\d+/', $text)) {
                    $suggestions['price'] = ['selector' => $sel, 'example' => $text];
                    break;
                }
            }
        }
        
        if (empty($suggestions)) {
            wp_send_json_error('Не знайдено селекторів. Спробуйте ручний режим.');
        }
        
        wp_send_json_success($suggestions);
    }
    
    public function ajax_test_selectors() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        
        $url = sanitize_text_field($_POST['url']);
        $selectors = $_POST['selectors'];
        
        $html = $this->get_html($url);
        if (!$html) wp_send_json_error('Не вдалося завантажити сторінку');
        
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $result = [];
        foreach ($selectors as $field => $selector) {
            if (empty($selector)) {
                $result[$field] = '⏭ пропущено';
                continue;
            }
            
            try {
                if ($field == 'image') {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $src = $nodes->item(0)->getAttribute('src') ?: $nodes->item(0)->getAttribute('data-src');
                        $result[$field] = $src ? '✅ ' . substr($src, 0, 80) : '❌ немає src';
                    } else {
                        $result[$field] = '❌ не знайдено';
                    }
                } else {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $value = trim(strip_tags($nodes->item(0)->textContent));
                        $result[$field] = $value ? '✅ ' . mb_substr($value, 0, 100) : '❌ порожнє';
                    } else {
                        $result[$field] = '❌ не знайдено';
                    }
                }
            } catch (Exception $e) {
                $result[$field] = '❌ помилка';
            }
        }
        
        wp_send_json_success($result);
    }
    
    public function ajax_start_parse() {
        check_ajax_referer('wsp_ajax_nonce', 'nonce');
        set_time_limit(0);
        
        $license_key = get_option('wsp_license_key', '');
        $site_url = sanitize_url($_POST['site_url']);
        $selectors = $_POST['selectors'];
        $product_link_selector = sanitize_text_field($_POST['product_link_selector']);
        $create_csv = $_POST['create_csv'] === 'true';
        $import_to_shop = $_POST['import_to_shop'] === 'true';
        $as_draft = $_POST['as_draft'] === 'true';
        
        $all_product_urls = $this->get_all_product_urls($site_url, $product_link_selector);
        
        if (empty($all_product_urls)) {
            wp_send_json_error('Не знайдено товарів. Перевірте селектор посилань.');
        }
        
        $parsed_products = [];
        $total = 0;
        
        foreach ($all_product_urls as $product_url) {
            $total++;
            if (!$this->monetization->can_import($total, $license_key)) {
                break;
            }
            
            $data = $this->parse_single_product($product_url, $selectors);
            if ($data && !empty($data['title'])) {
                $parsed_products[] = $data;
                if ($import_to_shop) {
                    $this->import_to_woocommerce($data, $as_draft);
                }
            }
            sleep(1);
        }
        
        $response = ['success' => true, 'total' => count($parsed_products)];
        
        if ($create_csv && !empty($parsed_products)) {
            $csv_url = $this->generate_csv($parsed_products);
            $response['csv_url'] = $csv_url;
        }
        
        wp_send_json_success($response);
    }
    
    private function get_all_product_urls($site_url, $link_selector) {
        $all_urls = [];
        $categories = $this->find_categories($site_url);
        
        foreach ($categories as $cat_url) {
            $urls = $this->get_urls_from_category($cat_url, $link_selector);
            $all_urls = array_merge($all_urls, $urls);
        }
        
        return array_unique($all_urls);
    }
    
    private function find_categories($site_url) {
        $html = $this->get_html($site_url);
        if (!$html) return [$site_url];
        
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $patterns = [
            '//a[contains(@href, "/category/")]',
            '//a[contains(@href, "/catalog/")]',
            '//a[contains(@href, "/product-category/")]',
            '//a[contains(@class, "category")]'
        ];
        
        $urls = [];
        foreach ($patterns as $pattern) {
            $nodes = $xpath->query($pattern);
            foreach ($nodes as $node) {
                $href = $node->getAttribute('href');
                if ($href && strpos($href, $site_url) !== false && !strpos($href, 'product')) {
                    $urls[] = $href;
                }
            }
        }
        
        return array_unique($urls) ?: [$site_url];
    }
    
    private function get_urls_from_category($category_url, $link_selector) {
        $urls = [];
        $current_url = $category_url;
        $page = 0;
        
        while ($current_url && $page < 30) {
            $html = $this->get_html($current_url);
            if (!$html) break;
            
            $dom = new DOMDocument();
            @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
            $xpath = new DOMXPath($dom);
            
            $nodes = $xpath->query($link_selector);
            foreach ($nodes as $node) {
                $href = $node->getAttribute('href');
                if ($href) {
                    if (filter_var($href, FILTER_VALIDATE_URL)) {
                        $urls[] = $href;
                    } elseif (strpos($href, 'http') !== 0) {
                        $urls[] = rtrim($site_url, '/') . '/' . ltrim($href, '/');
                    }
                }
            }
            
            $next = $xpath->query('//a[contains(@class, "next")] | //link[@rel="next"] | //a[contains(text(), "»")]');
            $current_url = $next && $next->length ? $next->item(0)->getAttribute('href') : null;
            $page++;
        }
        
        return $urls;
    }
    
    private function parse_single_product($url, $selectors) {
        $html = $this->get_html($url);
        if (!$html) return null;
        
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        $data = ['url' => $url];
        foreach ($selectors as $field => $selector) {
            if (empty($selector)) continue;
            
            try {
                if ($field == 'image') {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $data[$field] = $nodes->item(0)->getAttribute('src') ?: $nodes->item(0)->getAttribute('data-src');
                    }
                } elseif ($field == 'gallery') {
                    $data[$field] = [];
                    $nodes = $xpath->query($selector);
                    foreach ($nodes as $img) {
                        $src = $img->getAttribute('src') ?: $img->getAttribute('data-src');
                        if ($src) $data[$field][] = $src;
                    }
                } else {
                    $nodes = $xpath->query($selector);
                    if ($nodes && $nodes->length) {
                        $data[$field] = trim(strip_tags($nodes->item(0)->textContent));
                    }
                }
            } catch (Exception $e) {}
        }
        
        return $data;
    }
    
    private function get_html($url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $html = curl_exec($ch);
        curl_close($ch);
        return $html;
    }
    
    private function generate_csv($products) {
        if (empty($products)) return false;
        
        $upload_dir = wp_upload_dir();
        $csv_dir = $upload_dir['basedir'] . '/woo-parser-csv/';
        if (!file_exists($csv_dir)) mkdir($csv_dir, 0777, true);
        
        $filename = 'products_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = $csv_dir . $filename;
        
        $headers = array_keys($products[0]);
        $file = fopen($filepath, 'w');
        fputcsv($file, $headers);
        
        foreach ($products as $product) {
            $row = [];
            foreach ($headers as $header) {
                $value = $product[$header] ?? '';
                if (is_array($value)) $value = implode('|', $value);
                $row[] = $value;
            }
            fputcsv($file, $row);
        }
        fclose($file);
        
        return $upload_dir['baseurl'] . '/woo-parser-csv/' . $filename;
    }
    
    private function import_to_woocommerce($data, $as_draft = false) {
        if (!class_exists('WooCommerce')) return false;
        
        $title = $data['title'] ?? 'Без назви';
        $description = $data['description'] ?? '';
        $price = $data['price'] ?? '0';
        $sale_price = $data['sale_price'] ?? '';
        $image = $data['image'] ?? '';
        $gallery = $data['gallery'] ?? [];
        
        $post_status = $as_draft ? 'draft' : 'publish';
        
        $product_id = wp_insert_post([
            'post_title' => $title,
            'post_content' => $description,
            'post_type' => 'product',
            'post_status' => $post_status
        ]);
        
        if (!$product_id) return false;
        
        $price_num = floatval(preg_replace('/[^0-9.]/', '', $price));
        update_post_meta($product_id, '_regular_price', $price_num);
        
        if (!empty($sale_price)) {
            $sale_price_num = floatval(preg_replace('/[^0-9.]/', '', $sale_price));
            update_post_meta($product_id, '_sale_price', $sale_price_num);
            update_post_meta($product_id, '_price', $sale_price_num);
        } else {
            update_post_meta($product_id, '_price', $price_num);
        }
        
        if (!empty($image)) {
            $attach_id = $this->upload_image($image, $product_id);
            if ($attach_id) set_post_thumbnail($product_id, $attach_id);
        }
        
        if (!empty($gallery) && is_array($gallery)) {
            $gallery_ids = [];
            foreach (array_slice($gallery, 0, 10) as $img_url) {
                $id = $this->upload_image($img_url, $product_id);
                if ($id) $gallery_ids[] = $id;
            }
            if ($gallery_ids) {
                update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
            }
        }
        
        return $product_id;
    }
    
    private function upload_image($url, $parent_post_id = 0) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        
        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) return false;
        
        $file_array = ['name' => basename(parse_url($url, PHP_URL_PATH)), 'tmp_name' => $tmp];
        $attach_id = media_handle_sideload($file_array, $parent_post_id);
        
        @unlink($tmp);
        return is_wp_error($attach_id) ? false : $attach_id;
    }
}

new WooSmartParser();